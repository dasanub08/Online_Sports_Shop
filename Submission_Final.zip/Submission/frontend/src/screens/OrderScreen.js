import React from 'react';

function OrderScreen() {
    return (
        <div className="orderbox">
            <h2> Your Order is confirmed</h2>
            <h4>Thank you for Ordering with us</h4>
        </div>
    )
}
export default OrderScreen;