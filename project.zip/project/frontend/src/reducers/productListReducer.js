import { PRODUCT_LIST_REQ, PRODUCT_LIST_SUCC, PRODUCT_LIST_FAIL, PRODUCT_DETAILS_REQ, PRODUCT_DETAILS_SUCC, PRODUCT_DETAILS_FAIL } from "../constants/productConstants";

function productListReducer(state = { products: [] }, action) {
    switch (action.type) {
        case PRODUCT_LIST_REQ:
            return { loading: true };
        case PRODUCT_LIST_SUCC:
            return { loading: false, products: action.payload };
        case PRODUCT_LIST_FAIL:
            return { loading: false, error: action.payload }
        default:
            return state;
    }
}
function productDetailsReducer(state = { product: {} }, action) {
    switch (action.type) {
        case PRODUCT_DETAILS_REQ:
            return { loading: true };
        case PRODUCT_DETAILS_SUCC:
            return { loading: false, product: action.payload };
        case PRODUCT_DETAILS_FAIL:
            return { loading: false, error: action.payload }
        default:
            return state;
    }
}
export { productListReducer, productDetailsReducer }